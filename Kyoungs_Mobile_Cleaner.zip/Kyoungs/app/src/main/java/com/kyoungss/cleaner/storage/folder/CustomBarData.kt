package com.kyoungss.cleaner.storage.folder

class CustomBarData (
    val type: Int,
    var value: Int,
    var color: Int
)