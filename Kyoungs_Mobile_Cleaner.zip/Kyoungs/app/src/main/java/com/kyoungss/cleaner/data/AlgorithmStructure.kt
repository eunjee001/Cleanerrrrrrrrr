package com.kyoungss.cleaner.data
data class AlgorithmStructure(

    val name: Int,
    var level: Int,
    var speed: Int,
    var count: Int
//    var content: String

)