package com.kyoungss.cleaner.check.clean.progress

data class CleanProgressData(
    val type: Long,
    val appCount: String
)