package com.kyoungss.cleaner.storage.document

data class DocDiffData(
    val diffArray : Long
)